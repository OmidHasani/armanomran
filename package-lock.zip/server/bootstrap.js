import bcrypt from 'bcryptjs';
import { User } from './models.js';
import { ROLE_DEFAULTS } from './perms.js';

let dummyHash = '';

export function getDummyHash() {
  return dummyHash;
}

export async function ensureAdmin() {
  dummyHash = await bcrypt.hash('not-a-real-user', 12);
  const count = await User.countDocuments();
  if (count > 0) {
    await User.updateMany({ role: 'admin', $or: [{ perms: { $exists: false } }, { perms: { $size: 0 } }] }, { $set: { perms: ROLE_DEFAULTS.admin } });
    return;
  }
  const username = String(process.env.ADMIN_USERNAME || 'admin').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (password.length < 6) {
    console.error('No users exist. Set ADMIN_PASSWORD (at least 6 characters) and start again.');
    process.exit(1);
  }
  await User.create({
    username,
    passwordHash: await bcrypt.hash(password, 12),
    name: process.env.ADMIN_NAME || 'مدیر سیستم',
    role: 'admin',
    perms: ROLE_DEFAULTS.admin,
    active: true,
  });
  console.log('Initial admin user created:', username);
}
