import { Contract, Customer, LegalCase, Meta, Project, Reservation } from './models.js';
import { AppError } from './validate.js';
import { diffDays, nowTime, todayJ, uid } from './dates.js';

export const FOLLOW_ACTIONS = [
  { k: 'call', l: 'تماس تلفنی' },
  { k: 'sms', l: 'پیامک / پیام‌رسان' },
  { k: 'letter', l: 'اظهارنامه / نامه' },
  { k: 'visit', l: 'مراجعه حضوری' },
  { k: 'meeting', l: 'جلسه توافق' },
  { k: 'court', l: 'اقدام قضایی' },
  { k: 'other', l: 'سایر' },
];

export const FOLLOW_SUBJECTS = [
  { k: 'payment', l: 'وصول مبلغ' },
  { k: 'promise', l: 'وعده پرداخت' },
  { k: 'docs', l: 'مدارک و احراز' },
  { k: 'notice', l: 'اخطار حقوقی' },
  { k: 'settlement', l: 'تسویه / توافق' },
  { k: 'unit', l: 'وضعیت واحد / پروژه' },
  { k: 'other', l: 'سایر موارد' },
];

export const FOLLOW_RESULTS = [
  { k: 'no_answer', l: 'عدم پاسخ' },
  { k: 'promised', l: 'وعده پرداخت' },
  { k: 'partial', l: 'پرداخت جزئی' },
  { k: 'paid', l: 'تسویه شد' },
  { k: 'escalated', l: 'ارجاع بالاتر' },
  { k: 'refused', l: 'امتناع' },
  { k: 'other', l: 'سایر' },
];

export const CASE_STATUS = [
  { k: 'new', l: 'ارجاع‌شده' },
  { k: 'working', l: 'در حال پیگیری' },
  { k: 'waiting', l: 'در انتظار' },
  { k: 'done', l: 'مختومه' },
];

async function settings() {
  const meta = await Meta.findById('crm').lean();
  return {
    legalDays: Math.max(1, Number(meta?.legalDays) || 7),
    autoLegal: meta?.autoLegal !== false,
    fine: meta?.fine ?? 30000000,
    days: meta?.days ?? 20,
  };
}

function paidSum(contract) {
  return (contract.inst || []).filter((i) => i.paid).reduce((s, i) => s + (i.amt || 0), 0);
}

function customerSnap(customer = {}) {
  return {
    id: customer._id || customer.id || '',
    name: customer.name || '—',
    nid: customer.nid || '',
    phone: customer.phone || '',
    addr: customer.addr || '',
    father: customer.father || '',
  };
}

function projectSnap(project = {}) {
  return { id: project._id || project.id || '', name: project.name || '—', addr: project.addr || '' };
}

function unitSnap(unit = {}) {
  return {
    id: unit.id || '',
    no: unit.no || '—',
    floor: unit.floor || '',
    kind: unit.kind || '',
    area: unit.area || 0,
    total: unit.total || 0,
  };
}

export async function getAdminSettings() {
  return settings();
}

export async function saveAdminSettings(body) {
  const legalDays = Math.max(1, Math.min(3650, parseInt(String(body?.legalDays ?? 7), 10) || 7));
  const autoLegal = body?.autoLegal !== false && body?.autoLegal !== 'false' && body?.autoLegal !== 0;
  const fine = Math.max(0, Number(body?.fine) || 30000000);
  const days = Math.max(1, Math.min(3650, parseInt(String(body?.days ?? 20), 10) || 20));
  const now = new Date();
  await Meta.updateOne(
    { _id: 'crm' },
    {
      $set: { legalDays, autoLegal, fine, days, updatedAt: now },
      $setOnInsert: { createdAt: now, version: 0 },
    },
    { upsert: true },
  );
  return { legalDays, autoLegal, fine, days };
}

export async function syncLegalReferrals(by = 'سامانه') {
  const cfg = await settings();
  if (!cfg.autoLegal) return { created: 0, legalDays: cfg.legalDays };
  const [contracts, customers, projects, reservations] = await Promise.all([
    Contract.find().lean(),
    Customer.find().lean(),
    Project.find().lean(),
    Reservation.find().lean(),
  ]);
  const custMap = new Map(customers.map((c) => [String(c._id), c]));
  const projMap = new Map(projects.map((p) => [String(p._id), p]));
  const existing = new Set((await LegalCase.find({}, { sourceKey: 1 }).lean()).map((c) => c.sourceKey));
  const docs = [];
  const now = new Date();

  for (const contract of contracts) {
    const customer = custMap.get(String(contract.cust));
    const project = projMap.get(String(contract.proj));
    const unit = (project?.units || []).find((u) => u.id === contract.unit) || {};
    const paid = paidSum(contract);
    for (const inst of contract.inst || []) {
      if (inst.paid) continue;
      const d = diffDays(inst.date);
      if (d > -cfg.legalDays) continue;
      const sourceKey = `inst:${contract._id}:${inst.id}`;
      if (existing.has(sourceKey)) continue;
      docs.push({
        _id: uid(),
        sourceKey,
        kind: 'installment',
        status: 'new',
        priority: -d >= cfg.legalDays * 2 ? 'high' : 'normal',
        referredAt: now,
        referredBy: by,
        thresholdDays: cfg.legalDays,
        overdueDays: -d,
        customer: customerSnap(customer),
        project: projectSnap(project),
        unit: unitSnap(unit),
        contract: {
          id: String(contract._id),
          no: contract.no,
          type: contract.type,
          date: contract.date,
          total: contract.total,
          paid,
          remaining: Math.max(0, contract.total - paid),
        },
        installment: {
          id: inst.id,
          title: inst.title || '',
          amt: inst.amt || 0,
          date: inst.date,
          ref: inst.ref || '',
          paid: false,
        },
        chart: {
          due: inst.amt || 0,
          paid,
          remaining: Math.max(0, contract.total - paid),
          contractTotal: contract.total,
          overdueAmt: inst.amt || 0,
        },
        follows: [],
        createdAt: now,
        updatedAt: now,
      });
      existing.add(sourceKey);
    }
  }

  for (const reservation of reservations) {
    if (reservation.st !== 'active') continue;
    const rem = Math.max(0, (reservation.need || 0) - (reservation.pays || []).reduce((s, p) => s + (p.amt || 0), 0));
    if (rem <= 0) continue;
    const d = diffDays(reservation.deadline);
    if (d > -cfg.legalDays) continue;
    const sourceKey = `res:${reservation._id}`;
    if (existing.has(sourceKey)) continue;
    const customer = custMap.get(String(reservation.cust));
    const project = projMap.get(String(reservation.proj));
    const unit = (project?.units || []).find((u) => u.id === reservation.unit) || {};
    const paid = (reservation.pays || []).reduce((s, p) => s + (p.amt || 0), 0);
    docs.push({
      _id: uid(),
      sourceKey,
      kind: 'reservation',
      status: 'new',
      priority: -d >= cfg.legalDays * 2 ? 'high' : 'normal',
      referredAt: now,
      referredBy: by,
      thresholdDays: cfg.legalDays,
      overdueDays: -d,
      customer: customerSnap(customer),
      project: projectSnap(project),
      unit: unitSnap(unit),
      reservation: {
        id: String(reservation._id),
        no: reservation.no,
        need: reservation.need || 0,
        paid,
        deadline: reservation.deadline,
        st: reservation.st,
      },
      chart: {
        due: rem,
        paid,
        remaining: rem,
        contractTotal: reservation.need || 0,
        overdueAmt: rem,
      },
      follows: [],
      createdAt: now,
      updatedAt: now,
    });
    existing.add(sourceKey);
  }

  if (docs.length) {
    try {
      await LegalCase.insertMany(docs, { ordered: false });
    } catch (err) {
      if (err?.code !== 11000) throw err;
    }
  }
  return { created: docs.length, legalDays: cfg.legalDays };
}

export async function listLegalCases(query = {}) {
  await syncLegalReferrals('سامانه');
  const filter = {};
  if (query.status && CASE_STATUS.some((s) => s.k === query.status)) filter.status = query.status;
  const cases = await LegalCase.find(filter).sort({ priority: -1, overdueDays: -1, referredAt: -1 }).lean();
  return cases.map(serializeCase);
}

export async function getLegalCase(id) {
  const item = await LegalCase.findById(id).lean();
  if (!item) throw new AppError('پرونده حقوقی پیدا نشد', 404);
  return serializeCase(item);
}

export async function referManual(body, user) {
  const contractId = String(body?.contractId || '');
  const instId = String(body?.instId || '');
  if (!contractId || !instId) throw new AppError('قسط برای ارجاع مشخص نیست');
  const contract = await Contract.findById(contractId).lean();
  if (!contract) throw new AppError('قرارداد پیدا نشد', 404);
  const inst = (contract.inst || []).find((i) => i.id === instId);
  if (!inst) throw new AppError('قسط پیدا نشد', 404);
  if (inst.paid) throw new AppError('این قسط پرداخت شده و قابل ارجاع نیست');
  const sourceKey = `inst:${contract._id}:${inst.id}`;
  const exists = await LegalCase.findOne({ sourceKey }).lean();
  if (exists) return serializeCase(exists);
  const customer = await Customer.findById(contract.cust).lean();
  const project = await Project.findById(contract.proj).lean();
  const unit = (project?.units || []).find((u) => u.id === contract.unit) || {};
  const paid = paidSum(contract);
  const d = diffDays(inst.date);
  const cfg = await settings();
  const now = new Date();
  const doc = await LegalCase.create({
    _id: uid(),
    sourceKey,
    kind: 'installment',
    status: 'new',
    priority: 'high',
    referredAt: now,
    referredBy: user.name || user.username,
    thresholdDays: cfg.legalDays,
    overdueDays: Math.max(0, -d),
    customer: customerSnap(customer),
    project: projectSnap(project),
    unit: unitSnap(unit),
    contract: {
      id: String(contract._id),
      no: contract.no,
      type: contract.type,
      date: contract.date,
      total: contract.total,
      paid,
      remaining: Math.max(0, contract.total - paid),
    },
    installment: {
      id: inst.id,
      title: inst.title || '',
      amt: inst.amt || 0,
      date: inst.date,
      ref: inst.ref || '',
      paid: false,
    },
    chart: {
      due: inst.amt || 0,
      paid,
      remaining: Math.max(0, contract.total - paid),
      contractTotal: contract.total,
      overdueAmt: inst.amt || 0,
    },
    follows: [],
    createdAt: now,
    updatedAt: now,
  });
  return serializeCase(doc.toObject());
}

export async function updateLegalStatus(id, status, user) {
  if (!CASE_STATUS.some((s) => s.k === status)) throw new AppError('وضعیت نامعتبر است');
  const item = await LegalCase.findById(id);
  if (!item) throw new AppError('پرونده حقوقی پیدا نشد', 404);
  item.status = status;
  item.updatedAt = new Date();
  if (status === 'done') item.closedAt = new Date();
  if (status === 'working' && !item.assignedTo) {
    item.assignedTo = String(user._id);
    item.assignedName = user.name || user.username;
  }
  await item.save();
  return serializeCase(item.toObject());
}

export async function addFollowUp(id, body, user) {
  const item = await LegalCase.findById(id);
  if (!item) throw new AppError('پرونده حقوقی پیدا نشد', 404);
  const actions = Array.isArray(body?.actions) ? body.actions.filter((a) => FOLLOW_ACTIONS.some((x) => x.k === a)) : [];
  const subjects = Array.isArray(body?.subjects) ? body.subjects.filter((a) => FOLLOW_SUBJECTS.some((x) => x.k === a)) : [];
  const result = FOLLOW_RESULTS.some((x) => x.k === body?.result) ? body.result : 'other';
  const note = String(body?.note || '').trim();
  if (!actions.length && !subjects.length && !note) throw new AppError('حداقل یک اقدام، موضوع یا توضیح ثبت کنید');
  if (note.length > 4000) throw new AppError('توضیح پیگیری خیلی طولانی است');
  const next = String(body?.next || '').trim();
  const follow = {
    id: uid(),
    d: todayJ(),
    h: nowTime(),
    by: user.name || user.username,
    byId: String(user._id),
    actions,
    subjects,
    result,
    note,
    next,
    createdAt: new Date(),
  };
  item.follows.push(follow);
  if (result === 'paid') item.status = 'done';
  else if (result === 'promised' || next) item.status = 'waiting';
  else if (item.status === 'new') item.status = 'working';
  if (!item.assignedTo) {
    item.assignedTo = String(user._id);
    item.assignedName = user.name || user.username;
  }
  item.updatedAt = new Date();
  if (item.status === 'done') item.closedAt = new Date();
  await item.save();
  return serializeCase(item.toObject());
}

function serializeCase(doc) {
  const { _id, createdAt, updatedAt, closedAt, referredAt, follows = [], ...rest } = doc;
  return {
    id: String(_id),
    ...rest,
    follows: [...follows].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))),
    referredAt: referredAt || null,
    createdAt: createdAt || null,
    updatedAt: updatedAt || null,
    closedAt: closedAt || null,
  };
}

export async function legalStats() {
  await syncLegalReferrals('سامانه');
  const rows = await LegalCase.aggregate([{ $group: { _id: '$status', n: { $sum: 1 }, amt: { $sum: '$chart.overdueAmt' } } }]);
  const by = Object.fromEntries(CASE_STATUS.map((s) => [s.k, { count: 0, amount: 0 }]));
  for (const row of rows) {
    if (by[row._id]) by[row._id] = { count: row.n, amount: row.amt || 0 };
  }
  return by;
}
