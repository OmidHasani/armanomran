import mongoose from 'mongoose';
import { Contract, Customer, Lead, Meta, Project, Reservation } from './models.js';
import { AppError, trailingNumber, validateState } from './validate.js';

const DEFAULT_FINE = 30000000;
const DEFAULT_DAYS = 20;

function toClient(doc) {
  const { _id, createdAt, updatedAt, ...rest } = doc;
  return { id: _id, ...rest };
}

function maxTrailing(items, pick) {
  let max = 0;
  for (const item of items) max = Math.max(max, trailingNumber(pick(item)));
  return max;
}

async function replaceAll(Model, docs, session) {
  const existing = await Model.find({}, { createdAt: 1 }).session(session).lean();
  const created = new Map(existing.map((doc) => [String(doc._id), doc.createdAt]));
  const now = new Date();
  const ids = docs.map((doc) => doc._id);
  await Model.deleteMany({ _id: { $nin: ids } }).session(session);
  if (!docs.length) return;
  await Model.bulkWrite(docs.map((doc) => ({
    replaceOne: {
      filter: { _id: doc._id },
      replacement: {
        ...doc,
        createdAt: created.get(String(doc._id)) || now,
        updatedAt: now,
      },
      upsert: true,
    },
  })), { session });
}

function projectDoc(project) {
  return {
    _id: project.id,
    name: project.name,
    addr: project.addr || '',
    note: project.note || '',
    vcName: project.vcName || '',
    vcPhone: project.vcPhone || '',
    vcNote: project.vcNote || '',
    units: project.units.map((unit) => ({
      id: unit.id,
      no: unit.no,
      floor: unit.floor || '',
      kind: unit.kind || '',
      area: unit.area,
      ppm: unit.ppm,
      total: unit.total,
      st: unit.st,
    })),
  };
}

function customerDoc(customer) {
  const doc = {
    _id: customer.id,
    name: customer.name,
    father: customer.father || '',
    nid: customer.nid,
    bc: customer.bc || '',
    phone: customer.phone,
    addr: customer.addr || '',
    notes: customer.notes || [],
  };
  if (customer.kyc) doc.kyc = customer.kyc;
  return doc;
}

function contractDoc(contract) {
  const doc = {
    _id: contract.id,
    no: contract.no,
    type: contract.type,
    cust: contract.cust,
    proj: contract.proj,
    unit: contract.unit,
    date: contract.date,
    total: contract.total,
    dur: contract.dur || '',
    note: contract.note || '',
    inst: contract.inst.map((inst) => ({
      id: inst.id,
      title: inst.title || '',
      amt: inst.amt,
      date: inst.date,
      paid: !!inst.paid,
      pdate: inst.pdate || '',
      ref: inst.ref || '',
    })),
    hand: contract.hand || '',
  };
  if (typeof contract.auto === 'boolean') doc.auto = contract.auto;
  if (contract.fac?.length) doc.fac = contract.fac;
  if (contract.ed) doc.ed = contract.ed;
  return doc;
}

function reservationDoc(reservation) {
  const doc = {
    _id: reservation.id,
    no: reservation.no,
    cust: reservation.cust,
    proj: reservation.proj,
    unit: reservation.unit,
    need: reservation.need,
    fine: reservation.fine,
    deadline: reservation.deadline,
    date: reservation.date,
    st: reservation.st,
    pays: reservation.pays,
    by: reservation.by || '',
    appr: reservation.appr || '',
    log: reservation.log || [],
  };
  if (reservation.cancel) doc.cancel = reservation.cancel;
  if (reservation.ed) doc.ed = reservation.ed;
  return doc;
}

function leadDoc(lead) {
  return {
    _id: lead.id,
    name: lead.name,
    phone: lead.phone,
    src: lead.src || '',
    proj: lead.proj || '',
    stage: lead.stage,
    next: lead.next || '',
    loan: lead.loan || 'no',
    rep: lead.rep || '',
    note: lead.note || '',
    cust: lead.cust || '',
    vcName: lead.vcName || '',
    vcPhone: lead.vcPhone || '',
    visitAt: lead.visitAt || '',
    visitDoneAt: lead.visitDoneAt || '',
    h: lead.h || [],
  };
}

export async function loadState() {
  const [projects, customers, contracts, reservations, leads, meta] = await Promise.all([
    Project.find().sort({ createdAt: 1 }).lean(),
    Customer.find().sort({ createdAt: 1 }).lean(),
    Contract.find().sort({ createdAt: 1 }).lean(),
    Reservation.find().sort({ createdAt: 1 }).lean(),
    Lead.find().sort({ createdAt: 1 }).lean(),
    Meta.findById('crm').lean(),
  ]);
  return {
    version: meta?.version || 0,
    data: {
      projects: projects.map(toClient),
      customers: customers.map(toClient),
      contracts: contracts.map(toClient),
      reservations: reservations.map(toClient),
      leads: leads.map(toClient),
      cfg: {
        fine: meta?.fine ?? DEFAULT_FINE,
        days: meta?.days ?? DEFAULT_DAYS,
        legalDays: meta?.legalDays ?? 7,
        autoLegal: meta?.autoLegal !== false,
      },
      me: meta?.me || '',
      pn: meta?.pn ?? 1000,
      cn: meta?.cn ?? 1000,
      rn: meta?.rn ?? 1000,
    },
  };
}

export async function saveState(user, version, raw) {
  const data = validateState(raw);
  const cn = Math.max(data.cn || 0, maxTrailing(data.contracts, (contract) => contract.no), 1000);
  const rn = Math.max(data.rn || 0, maxTrailing(data.reservations, (reservation) => reservation.no), 1000);
  const pn = Math.max(
    data.pn || 0,
    maxTrailing(data.reservations.flatMap((reservation) => reservation.pays), (pay) => pay.id),
    1000,
  );
  let result = null;
  const session = await mongoose.startSession();
  try {
    await session.withTransaction(async () => {
      const meta = await Meta.findById('crm').session(session);
      const current = meta?.version || 0;
      if ((version || 0) !== current) {
        const error = new AppError('شخص دیگری داده‌ها را تغییر داده است. صفحه را تازه‌سازی کنید.', 409);
        error.version = current;
        throw error;
      }
      await replaceAll(Project, data.projects.map(projectDoc), session);
      await replaceAll(Customer, data.customers.map(customerDoc), session);
      await replaceAll(Contract, data.contracts.map(contractDoc), session);
      await replaceAll(Reservation, data.reservations.map(reservationDoc), session);
      await replaceAll(Lead, data.leads.map(leadDoc), session);
      const now = new Date();
      const nextVersion = current + 1;
      await Meta.updateOne(
        { _id: 'crm' },
        {
          $set: {
            version: nextVersion,
            fine: data.cfg?.fine > 0 ? data.cfg.fine : (meta?.fine ?? DEFAULT_FINE),
            days: data.cfg?.days > 0 ? data.cfg.days : (meta?.days ?? DEFAULT_DAYS),
            me: data.me || '',
            pn,
            cn,
            rn,
            updatedBy: user.username,
            updatedAt: now,
          },
          $setOnInsert: { createdAt: now },
        },
        { upsert: true, session },
      );
      result = { version: nextVersion, pn, cn, rn };
    });
  } catch (err) {
    if (err instanceof AppError) throw err;
    if (err?.code === 11000 || err?.cause?.code === 11000) {
      throw new AppError('یک مقدار یکتا تکراری است. شماره قرارداد، رزرو یا کد ملی را بررسی کنید.', 409);
    }
    throw err;
  } finally {
    await session.endSession();
  }
  if (!result) throw new AppError('ذخیره انجام نشد', 500);
  return result;
}
