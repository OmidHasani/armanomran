import assert from 'node:assert/strict';
import test from 'node:test';
import { validateState } from './validate.js';

function base() {
  return {
    projects: [{
      id: 'proj0001',
      name: 'برج آسمان',
      addr: 'تهران',
      note: '',
      units: [{
        id: 'unit0001',
        no: '12',
        floor: '3',
        kind: 'مسکونی',
        area: 80,
        ppm: 1000000,
        total: 80000000,
        st: 'free',
      }],
    }],
    customers: [{
      id: 'cust0001',
      name: 'علی رضایی',
      father: 'حسن',
      nid: '۰۰۱۳۵۴۲۴۱۹',
      bc: '123',
      phone: '۰۹۱۲۱۲۳۴۵۶۷',
      addr: 'تهران',
    }],
    contracts: [],
    reservations: [],
    leads: [],
    cfg: {},
    me: '',
    pn: 1000,
    cn: 1000,
    rn: 1000,
  };
}

test('normalizes digits and keeps an empty crm valid', () => {
  const data = validateState(base());
  assert.equal(data.customers[0].nid, '0013542419');
  assert.equal(data.customers[0].phone, '09121234567');
  assert.equal(data.projects[0].units[0].st, 'free');
});

test('marks a contracted unit as sold and strips script from the document', () => {
  const raw = base();
  raw.projects[0].units[0].st = 'free';
  raw.contracts.push({
    id: 'cont0001',
    no: 'ق-۱۰۰۱',
    type: 'invest',
    cust: 'cust0001',
    proj: 'proj0001',
    unit: 'unit0001',
    date: '1404/01/15',
    total: 80000000,
    dur: '12',
    note: '',
    inst: [{
      id: 'inst0001',
      title: 'پیش‌پرداخت',
      amt: 80000000,
      date: '1404/01/15',
      paid: false,
      pdate: '',
      ref: '',
    }],
    ed: { c: '<p>سلام</p><script>alert(1)</script><img src=x onerror=alert(1)>', dm: '<p>یادآوری</p>' },
  });
  const data = validateState(raw);
  assert.equal(data.projects[0].units[0].st, 'sold');
  assert.match(data.contracts[0].ed.c, /سلام/);
  assert.doesNotMatch(data.contracts[0].ed.c, /script|onerror/i);
});

test('rejects a repeated payment reference', () => {
  const raw = base();
  raw.projects[0].units.push({
    id: 'unit0002', no: '13', floor: '3', kind: 'مسکونی', area: 70, ppm: 1, total: 70, st: 'res',
  });
  const pay = (id, ref) => ({
    id, amt: 1000, date: '1404/02/01', ref, acct: '6037', payer: 'علی رضایی', tp: false, rel: '', appv: '', s: 'ok',
  });
  raw.reservations.push({
    id: 'resv0001',
    no: 'ر-1001',
    cust: 'cust0001',
    proj: 'proj0001',
    unit: 'unit0001',
    need: 5000,
    fine: 1000,
    deadline: '1404/03/01',
    date: '1404/02/01',
    st: 'active',
    pays: [pay('پ-1001', 'ABC-12')],
    by: 'کارشناس',
    appr: 'مدیر',
    log: [{ d: '1404/02/01', h: '10:15', by: 'کارشناس', t: 'ثبت' }],
  });
  raw.reservations.push({
    id: 'resv0002',
    no: 'ر-1002',
    cust: 'cust0001',
    proj: 'proj0001',
    unit: 'unit0002',
    need: 5000,
    fine: 1000,
    deadline: '1404/03/01',
    date: '1404/02/01',
    st: 'active',
    pays: [pay('پ-1002', 'abc-12')],
    by: 'کارشناس',
    appr: 'مدیر',
    log: [],
  });
  assert.throws(() => validateState(raw), /شماره پیگیری/);
});

test('rejects a contract whose customer does not exist', () => {
  const raw = base();
  raw.contracts.push({
    id: 'cont0001',
    no: 'ق-1001',
    type: 'lease',
    cust: 'missing1',
    proj: 'proj0001',
    unit: 'unit0001',
    date: '1404/01/15',
    total: 10,
    dur: '12',
    inst: [],
  });
  assert.throws(() => validateState(raw), /مشتری ناموجود/);
});
